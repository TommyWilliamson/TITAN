Thanks to those who contributed code and ideas, including:

```
@aldebaran1 (robustness)
@rpavlick (multiple features + functions)
@cchuravy (Ellipsoid parameters)
@jprMesh  (more conversion functions)
@Fil (docs)
@SamuelMarks (docs)
@Yozh2 (numerous ellipsoids and tests)
```
